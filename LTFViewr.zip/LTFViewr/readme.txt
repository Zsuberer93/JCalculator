Please keep the INI file and the executable file in the same folder. No 
Installation is needed.

LTFViewer 5.2u supports ANSI and Unicode. It currently does not support
Unicode big endian and UTF-8.

LTFViewer 5.2u requires Windows NT and up.
